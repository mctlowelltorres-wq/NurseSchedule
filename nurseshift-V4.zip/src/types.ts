export type Role = 'admin' | 'head_nurse' | 'nurse';

export interface UserProfile {
  uid: string;
  email: string;
  role: Role;
  displayName?: string;
  department?: string;
}

export interface Nurse {
  id: string;
  name: string;
  department: string;
  position: string;
}

export type ShiftType = '6AM-6PM' | '6PM-6AM' | '6AM-2PM' | '2PM-10PM' | '10PM-6AM' | '8AM-5PM' | 'RD' | 'RRD';

export interface Schedule {
  id?: string;
  nurseId: string;
  date: string; // YYYY-MM-DD
  shift: ShiftType;
  updatedBy: string;
  updatedAt: string;
}

export interface AppSettings {
  systemName: string;
  backgroundUrl: string;
  primaryColor: string;
  departments: string[];
}

export interface ORSchedule {
  id?: string;
  patientName: string;
  operationType: string;
  doctor: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  status: 'pending' | 'done';
  updatedBy: string;
  updatedAt: string;
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: string;
  path: string | null;
  authInfo: any;
}
