import React, { useState, useEffect, useMemo } from 'react';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { Nurse, Schedule, AppSettings, UserProfile } from '../types';
import ScheduleGrid from './ScheduleGrid';
import ORPlanner from './ORPlanner';
import { Calendar, LogOut, User, Users, Activity } from 'lucide-react';
import { cn } from '../lib/utils';

interface Props {
  settings: AppSettings;
  userProfile: UserProfile | null;
}

export default function NurseView({ settings, userProfile }: Props) {
  const [nurses, setNurses] = useState<Nurse[]>([]);
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [activeTab, setActiveTab] = useState<'nurse' | 'or'>('nurse');

  useEffect(() => {
    const nursesUnsub = onSnapshot(collection(db, 'nurses'), (snapshot) => {
      setNurses(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Nurse)));
    });

    const schedulesUnsub = onSnapshot(collection(db, 'schedules'), (snapshot) => {
      setSchedules(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Schedule)));
    });

    setLoading(false);
    return () => {
      nursesUnsub();
      schedulesUnsub();
    };
  }, []);

  const filteredNurses = useMemo(() => {
    if (userProfile?.department) {
      return nurses.filter(n => n.department === userProfile.department);
    }
    return nurses;
  }, [nurses, userProfile]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-10 h-10 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 sm:p-6">
      <div className="max-w-[98%] mx-auto relative">
        <header className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-2 bg-white/50 border border-slate-200 p-1 rounded-xl glass-card">
            <button
              onClick={() => setActiveTab('nurse')}
              className={cn(
                "px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2",
                activeTab === 'nurse' ? "bg-indigo-600 text-white shadow-md" : "text-slate-500 hover:bg-white"
              )}
            >
              <Users className="w-4 h-4" />
              Nurse Schedule
            </button>
            {(userProfile?.role === 'admin' || userProfile?.department?.toUpperCase() === 'OR') && (
              <button
                onClick={() => setActiveTab('or')}
                className={cn(
                  "px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2",
                  activeTab === 'or' ? "bg-indigo-600 text-white shadow-md" : "text-slate-500 hover:bg-white"
                )}
              >
                <Activity className="w-4 h-4" />
                OR Planner
              </button>
            )}
          </div>
          <button
            onClick={() => auth.signOut()}
            className="flex items-center gap-2 text-slate-400 hover:text-red-600 font-semibold transition-colors px-3 py-1.5 rounded-lg hover:bg-red-50/50 text-xs border border-slate-200/50 glass-card"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </header>

        <div className="mt-4">
          {activeTab === 'nurse' ? (
            <div className="glass-card rounded-2xl overflow-hidden">
              <ScheduleGrid
                nurses={filteredNurses}
                schedules={schedules}
                isAdmin={false}
                currentMonth={currentMonth}
                onMonthChange={setCurrentMonth}
              />
            </div>
          ) : (
            <ORPlanner isAdmin={false} userProfile={userProfile} />
          )}
        </div>
      </div>
    </div>
  );
}
