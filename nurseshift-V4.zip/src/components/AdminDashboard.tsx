import React, { useState, useEffect, useMemo } from 'react';
import { collection, onSnapshot, query, setDoc, doc, deleteDoc, addDoc, serverTimestamp } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { Nurse, Schedule, ShiftType, AppSettings, UserProfile, Role } from '../types';
import ScheduleGrid from './ScheduleGrid';
import ORPlanner from './ORPlanner';
import { Plus, Trash2, Users, Calendar, LogOut, UserPlus, Settings as SettingsIcon, Image as ImageIcon, Type, Activity } from 'lucide-react';
import { cn } from '../lib/utils';

interface Props {
  settings: AppSettings;
  userProfile: UserProfile | null;
}

export default function AdminDashboard({ settings, userProfile }: Props) {
  const [nurses, setNurses] = useState<Nurse[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [loading, setLoading] = useState(true);
  const [newNurse, setNewNurse] = useState({ name: '', position: 'Staff Nurse', department: 'Nursing' });
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDepartment, setSelectedDepartment] = useState<string>('All');
  const [activeTab, setActiveTab] = useState<'nurse' | 'or'>('nurse');
  
  // Settings state
  const [editSettings, setEditSettings] = useState<AppSettings>(settings);
  const [savingSettings, setSavingSettings] = useState(false);
  const [newDepartment, setNewDepartment] = useState('');

  useEffect(() => {
    setEditSettings(settings);
  }, [settings]);

  useEffect(() => {
    const nursesUnsub = onSnapshot(collection(db, 'nurses'), (snapshot) => {
      setNurses(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Nurse)));
    });

    const usersUnsub = onSnapshot(collection(db, 'users'), (snapshot) => {
      setUsers(snapshot.docs.map(doc => ({ ...doc.data() } as UserProfile)));
    });

    const schedulesUnsub = onSnapshot(collection(db, 'schedules'), (snapshot) => {
      setSchedules(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Schedule)));
    });

    setLoading(false);
    return () => {
      nursesUnsub();
      usersUnsub();
      schedulesUnsub();
    };
  }, []);

  useEffect(() => {
    if (userProfile?.role === 'head_nurse' && userProfile.department) {
      setSelectedDepartment(userProfile.department);
    }
  }, [userProfile]);

  const handleUpdateRole = async (userId: string, newRole: Role, department?: string) => {
    try {
      await setDoc(doc(db, 'users', userId), { role: newRole, department: department || '' }, { merge: true });
    } catch (err) {
      console.error('Error updating role:', err);
    }
  };

  const handleUpdateUserDepartment = async (userId: string, department: string) => {
    try {
      await setDoc(doc(db, 'users', userId), { department }, { merge: true });
    } catch (err) {
      console.error('Error updating user department:', err);
    }
  };

  const handleAddNurse = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNurse.name) return;
    try {
      await addDoc(collection(db, 'nurses'), newNurse);
      setNewNurse({ name: '', position: 'Staff Nurse', department: 'Nursing' });
    } catch (err) {
      console.error('Error adding nurse:', err);
    }
  };

  const handleDeleteNurse = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this nurse?')) return;
    try {
      await deleteDoc(doc(db, 'nurses', id));
    } catch (err) {
      console.error('Error deleting nurse:', err);
    }
  };

  const handleUpdateSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);
    try {
      await setDoc(doc(db, 'settings', 'global'), editSettings);
      alert('Settings updated successfully!');
    } catch (err) {
      console.error('Error updating settings:', err);
      alert('Failed to update settings.');
    } finally {
      setSavingSettings(false);
    }
  };

  const handleShiftChange = async (nurseId: string, date: string, shift: ShiftType) => {
    const scheduleId = `${nurseId}_${date}`;
    try {
      await setDoc(doc(db, 'schedules', scheduleId), {
        nurseId,
        date,
        shift,
        updatedBy: auth.currentUser?.uid,
        updatedAt: new Date().toISOString(),
      });
    } catch (err) {
      console.error('Error updating shift:', err);
    }
  };

  const handleAddDepartment = () => {
    if (!newDepartment.trim()) return;
    if (editSettings.departments.includes(newDepartment.trim())) return;
    setEditSettings({
      ...editSettings,
      departments: [...editSettings.departments, newDepartment.trim()].sort()
    });
    setNewDepartment('');
  };

  const handleRemoveDepartment = (dept: string) => {
    setEditSettings({
      ...editSettings,
      departments: editSettings.departments.filter(d => d !== dept)
    });
  };

  const departments = useMemo(() => {
    return ['All', ...(settings.departments || [])].sort();
  }, [settings.departments]);

  const filteredNurses = useMemo(() => {
    if (selectedDepartment === 'All') return nurses;
    return nurses.filter(n => n.department === selectedDepartment);
  }, [nurses, selectedDepartment]);

  useEffect(() => {
    if (userProfile?.role === 'head_nurse' && userProfile.department) {
      setSelectedDepartment(userProfile.department);
    }
  }, [userProfile]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-10 h-10 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 sm:p-6">
      <div className="max-w-[98%] mx-auto relative">
        <header className="mb-8 flex justify-between items-center">
          <div className="flex items-center gap-2 bg-white/50 border border-slate-200 p-1 rounded-xl glass-card">
            <button
              onClick={() => setActiveTab('nurse')}
              className={cn(
                "px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2",
                activeTab === 'nurse' ? "bg-indigo-600 text-white shadow-md" : "text-slate-500 hover:bg-white"
              )}
            >
              <Users className="w-4 h-4" />
              Nurse Schedule
            </button>
            {(userProfile?.role === 'admin' || userProfile?.department?.toUpperCase() === 'OR' || auth.currentUser?.email === 'mct.lowelltorres@gmail.com') && (
              <button
                onClick={() => setActiveTab('or')}
                className={cn(
                  "px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2",
                  activeTab === 'or' ? "bg-indigo-600 text-white shadow-md" : "text-slate-500 hover:bg-white"
                )}
              >
                <Activity className="w-4 h-4" />
                OR Planner
              </button>
            )}
          </div>
          <button
            onClick={() => auth.signOut()}
            className="flex items-center gap-2 text-slate-400 hover:text-red-600 font-semibold transition-colors px-3 py-1.5 rounded-lg hover:bg-red-50/50 text-xs border border-slate-200/50 glass-card"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-1 space-y-8">
            {(userProfile?.role === 'admin' || auth.currentUser?.email === 'mct.lowelltorres@gmail.com') && (
              <section className="glass-card p-6 rounded-2xl">
                <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                  <SettingsIcon className="w-5 h-5 text-indigo-600" />
                  System Settings
                </h2>
                <form onSubmit={handleUpdateSettings} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5 flex items-center gap-2">
                      <Type className="w-3 h-3" />
                      System Name
                    </label>
                    <input
                      type="text"
                      value={editSettings.systemName}
                      onChange={(e) => setEditSettings({ ...editSettings, systemName: e.target.value })}
                      className="w-full p-3 bg-white/50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                      placeholder="e.g. NurseShift Pro"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5 flex items-center justify-between">
                      <span className="flex items-center gap-2">
                        <ImageIcon className="w-3 h-3" />
                        Background URL
                      </span>
                      <span className="text-[10px] text-indigo-500 lowercase">Use direct image links</span>
                    </label>
                    <textarea
                      value={editSettings.backgroundUrl}
                      onChange={(e) => setEditSettings({ ...editSettings, backgroundUrl: e.target.value })}
                      className="w-full p-3 bg-white/50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all h-24 resize-none text-sm"
                      placeholder="https://images.unsplash.com/..."
                    />
                    {editSettings.backgroundUrl && (
                      <div className="mt-2 relative group">
                        <div className="text-[10px] font-bold text-slate-400 mb-1 uppercase tracking-wider">Preview:</div>
                        <div className="w-full h-24 rounded-lg overflow-hidden border border-slate-200 bg-slate-100">
                          <img 
                            src={editSettings.backgroundUrl} 
                            alt="Preview" 
                            className="w-full h-full object-cover"
                            onError={(e) => (e.currentTarget.src = 'https://via.placeholder.com/400x200?text=Invalid+Image+URL')}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5 flex items-center gap-2">
                      <Users className="w-3 h-3" />
                      Manage Departments
                    </label>
                    <div className="flex gap-2 mb-3">
                      <input
                        type="text"
                        value={newDepartment}
                        onChange={(e) => setNewDepartment(e.target.value)}
                        className="flex-1 p-2 bg-white/50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                        placeholder="New Department..."
                      />
                      <button
                        type="button"
                        onClick={handleAddDepartment}
                        className="p-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all active:scale-95"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto p-1 custom-scrollbar">
                      {(editSettings.departments || []).map(dept => (
                        <div key={dept} className="flex items-center gap-1 bg-white border border-slate-200 px-2 py-1 rounded-lg text-[10px] font-bold text-slate-600 group">
                          {dept}
                          <button
                            type="button"
                            onClick={() => handleRemoveDepartment(dept)}
                            className="text-slate-300 hover:text-red-500 transition-colors"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                  <button
                    type="submit"
                    disabled={savingSettings}
                    className="w-full bg-slate-900 text-white py-3 px-4 rounded-xl font-bold hover:bg-slate-800 transition-all shadow-lg active:scale-[0.98] disabled:opacity-50"
                  >
                    {savingSettings ? 'Saving...' : 'Update Settings'}
                  </button>
                </form>
              </section>
            )}

            <section className="glass-card p-6 rounded-2xl">
              <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-indigo-600" />
                Add New Nurse
              </h2>
              <form onSubmit={handleAddNurse} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Full Name</label>
                  <input
                    type="text"
                    value={newNurse.name}
                    onChange={(e) => setNewNurse({ ...newNurse, name: e.target.value })}
                    className="w-full p-3 bg-white/50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                    placeholder="e.g. Ashley Eye Damaso"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Department</label>
                  <select
                    value={newNurse.department}
                    onChange={(e) => setNewNurse({ ...newNurse, department: e.target.value })}
                    className="w-full p-3 bg-white/50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  >
                    {(settings.departments || []).map(dept => (
                      <option key={dept} value={dept}>{dept}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Position</label>
                  <select
                    value={newNurse.position}
                    onChange={(e) => setNewNurse({ ...newNurse, position: e.target.value })}
                    className="w-full p-3 bg-white/50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  >
                    <option>Head Nurse</option>
                    <option>Staff Nurse</option>
                    <option>Junior Nurse</option>
                    <option>Senior Nurse</option>
                    <option>Trainee</option>
                    <option>Nursing Assistant</option>
                  </select>
                </div>
                <button
                  type="submit"
                  className="w-full bg-indigo-600 text-white py-3 px-4 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 active:scale-[0.98]"
                >
                  Add Nurse
                </button>
              </form>
            </section>

            {(userProfile?.role === 'admin' || auth.currentUser?.email === 'mct.lowelltorres@gmail.com') && (
              <section className="glass-card p-6 rounded-2xl">
                <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                  <Users className="w-5 h-5 text-indigo-600" />
                  User Accounts
                </h2>
                <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                  {users.map(u => (
                    <div key={u.uid} className="p-3 bg-white/40 rounded-xl border border-white/20">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                          {u.photoURL ? (
                            <img src={u.photoURL} alt="" className="w-8 h-8 rounded-full border border-white/50" />
                          ) : (
                            <div className="w-8 h-8 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center font-bold text-xs">
                              {u.displayName?.charAt(0) || u.email.charAt(0)}
                            </div>
                          )}
                          <div className="overflow-hidden">
                            <div className="text-sm font-bold text-slate-900 truncate">{u.displayName || 'Anonymous'}</div>
                            <div className="text-[10px] text-slate-400 truncate">{u.email}</div>
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-col gap-2">
                        <div className="flex items-center justify-between gap-2">
                          <span className={cn(
                            "text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider",
                            u.role === 'admin' ? "bg-indigo-100 text-indigo-600" : 
                            u.role === 'head_nurse' ? "bg-purple-100 text-purple-600" :
                            "bg-slate-100 text-slate-500"
                          )}>
                            {u.role}
                          </span>
                          {u.email !== 'mct.lowelltorres@gmail.com' && (
                            <select
                              value={u.role}
                              onChange={(e) => handleUpdateRole(u.uid, e.target.value as Role, u.department)}
                              className="text-[10px] font-bold bg-white/50 border border-slate-200 rounded-lg p-1 outline-none"
                            >
                              <option value="nurse">Set as Nurse</option>
                              <option value="head_nurse">Set as Head Nurse</option>
                              <option value="admin">Set as Admin</option>
                            </select>
                          )}
                        </div>
                        {u.email !== 'mct.lowelltorres@gmail.com' && (
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-bold text-slate-400 uppercase">Dept:</span>
                            <select
                              value={u.department || ''}
                              onChange={(e) => handleUpdateUserDepartment(u.uid, e.target.value)}
                              className="text-[10px] font-bold bg-white/50 border border-slate-200 rounded-lg p-1 outline-none flex-1"
                            >
                              <option value="">No Department</option>
                              {(settings.departments || []).map(d => (
                                <option key={d} value={d}>{d}</option>
                              ))}
                            </select>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            <section className="glass-card p-6 rounded-2xl">
              <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-600" />
                Nurse Directory
              </h2>
              <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                {nurses.map(nurse => (
                  <div key={nurse.id} className="flex items-center justify-between p-3 bg-white/40 rounded-xl border border-white/20 group">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-white text-indigo-600 border border-indigo-100 rounded-lg flex items-center justify-center font-bold text-xs">
                        {nurse.name.charAt(0)}
                      </div>
                      <div>
                        <div className="text-sm font-bold text-slate-900">{nurse.name}</div>
                        <div className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">{nurse.position}</div>
                      </div>
                    </div>
                    <button
                      onClick={() => handleDeleteNurse(nurse.id)}
                      className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
                {nurses.length === 0 && (
                  <p className="text-center text-slate-400 text-sm py-8 italic">No nurses added yet.</p>
                )}
              </div>
            </section>
          </div>

          <div className="lg:col-span-3 space-y-6">
            {activeTab === 'nurse' ? (
              <>
                <div className="glass-card p-4 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
                      <Users className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-900">Department Filter</h3>
                      <p className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">Viewing: {selectedDepartment}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    {departments.map(dept => (
                      <button
                        key={dept}
                        onClick={() => setSelectedDepartment(dept)}
                        disabled={userProfile?.role === 'head_nurse' && userProfile.department && userProfile.department !== dept}
                        className={cn(
                          "px-4 py-2 rounded-xl text-xs font-bold transition-all active:scale-95 whitespace-nowrap",
                          selectedDepartment === dept 
                            ? "bg-indigo-600 text-white shadow-lg shadow-indigo-100" 
                            : "bg-white/50 text-slate-500 hover:bg-white border border-slate-200",
                          userProfile?.role === 'head_nurse' && userProfile.department && userProfile.department !== dept && "opacity-30 cursor-not-allowed"
                        )}
                      >
                        {dept}
                      </button>
                    ))}
                  </div>
                </div>

                <ScheduleGrid
                  nurses={filteredNurses}
                  schedules={schedules}
                  isAdmin={true}
                  onShiftChange={handleShiftChange}
                  currentMonth={currentMonth}
                  onMonthChange={setCurrentMonth}
                />
              </>
            ) : (
              <ORPlanner isAdmin={true} userProfile={userProfile} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
