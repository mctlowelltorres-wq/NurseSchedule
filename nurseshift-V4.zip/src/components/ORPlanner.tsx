import React, { useState, useEffect, useMemo } from 'react';
import { collection, onSnapshot, query, setDoc, doc, deleteDoc, addDoc, where, orderBy } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { ORSchedule, UserProfile } from '../types';
import { Plus, Trash2, Calendar, ChevronLeft, ChevronRight, Clock, User, Activity, UserCog, Download, CheckCircle2, Circle } from 'lucide-react';
import { format, addMonths, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, setDate } from 'date-fns';
import { cn } from '../lib/utils';
import * as XLSX from 'xlsx';

interface Props {
  isAdmin: boolean;
  userProfile: UserProfile | null;
}

export default function ORPlanner({ isAdmin, userProfile }: Props) {
  const [schedules, setSchedules] = useState<ORSchedule[]>([]);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [newSchedule, setNewSchedule] = useState({
    patientName: '',
    operationType: '',
    doctor: '',
    date: format(new Date(), 'yyyy-MM-dd'),
    time: '08:00',
    status: 'pending' as const
  });

  const canEdit = useMemo(() => {
    return isAdmin || (userProfile?.role === 'head_nurse' && userProfile?.department?.toUpperCase() === 'OR');
  }, [isAdmin, userProfile]);

  useEffect(() => {
    const q = query(collection(db, 'or_schedules'), orderBy('date', 'asc'), orderBy('time', 'asc'));
    const unsub = onSnapshot(q, (snapshot) => {
      setSchedules(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ORSchedule)));
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const days = useMemo(() => {
    const start = startOfMonth(currentMonth);
    const end = endOfMonth(currentMonth);
    const interval = eachDayOfInterval({
      start,
      end
    });
    return interval;
  }, [currentMonth]);

  const handleAddSchedule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting || !newSchedule.patientName || !newSchedule.operationType || !newSchedule.doctor) return;

    setIsSubmitting(true);
    try {
      await addDoc(collection(db, 'or_schedules'), {
        ...newSchedule,
        status: 'pending',
        updatedBy: auth.currentUser?.uid,
        updatedAt: new Date().toISOString()
      });
      setShowAddModal(false);
      setNewSchedule({
        patientName: '',
        operationType: '',
        doctor: '',
        date: format(new Date(), 'yyyy-MM-dd'),
        time: '08:00',
        status: 'pending'
      });
    } catch (err) {
      console.error('Error adding OR schedule:', err);
      alert('Failed to save schedule. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleStatus = async (schedule: ORSchedule) => {
    if (!canEdit) return;
    try {
      const newStatus = schedule.status === 'done' ? 'pending' : 'done';
      await setDoc(doc(db, 'or_schedules', schedule.id!), {
        status: newStatus,
        updatedBy: auth.currentUser?.uid,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    } catch (err) {
      console.error('Error toggling status:', err);
    }
  };

  const handleExportData = () => {
    const dataToExport = schedules.map(s => ({
      Date: s.date,
      Time: s.time,
      'Patient Name': s.patientName,
      'Operation Type': s.operationType,
      Doctor: s.doctor,
      Status: s.status.toUpperCase()
    }));

    const ws = XLSX.utils.json_to_sheet(dataToExport);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "OR Schedules");
    XLSX.writeFile(wb, `OR_Schedules_${format(new Date(), 'yyyy-MM-dd')}.xlsx`);
  };

  const handleDeleteSchedule = async (id: string) => {
    if (!id) {
      console.error('No schedule ID provided for deletion');
      return;
    }
    if (!window.confirm('Are you sure you want to delete this schedule?')) return;
    try {
      console.log('Attempting to delete schedule:', id);
      await deleteDoc(doc(db, 'or_schedules', id));
      console.log('Successfully deleted schedule:', id);
    } catch (err) {
      console.error('Error deleting OR schedule:', err);
      alert('Failed to delete schedule. You may not have permission or there was a connection error.');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="w-8 h-8 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 glass-card p-6 rounded-2xl">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-indigo-600 text-white rounded-2xl shadow-lg shadow-indigo-100">
            <Activity className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">OR Operation Planner</h2>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Operating Room Department</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={handleExportData}
            className="flex items-center gap-2 bg-emerald-600 text-white px-4 py-2.5 rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100 active:scale-95"
          >
            <Download className="w-5 h-5" />
            Export Data
          </button>

          <div className="flex items-center gap-2 bg-white/50 border border-slate-200 p-1 rounded-xl">
            <button
              onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
              className="p-2 hover:bg-white rounded-lg transition-all text-slate-600"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="px-4 font-bold text-slate-700 min-w-[140px] text-center">
              {format(currentMonth, 'MMMM yyyy')}
            </div>
            <button
              onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
              className="p-2 hover:bg-white rounded-lg transition-all text-slate-600"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          {canEdit && (
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2.5 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 active:scale-95"
            >
              <Plus className="w-5 h-5" />
              Add Operation
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        {days.map(day => {
          const daySchedules = schedules.filter(s => s.date === format(day, 'yyyy-MM-dd'));
          return (
            <div key={day.toISOString()} className="glass-card rounded-2xl overflow-hidden flex flex-col h-full">
              <div className={cn(
                "p-3 text-center border-b border-slate-100",
                isSameDay(day, new Date()) ? "bg-indigo-50" : "bg-slate-50/50"
              )}>
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{format(day, 'EEEE')}</div>
                <div className={cn(
                  "text-lg font-black",
                  isSameDay(day, new Date()) ? "text-indigo-600" : "text-slate-700"
                )}>
                  {format(day, 'd')}
                </div>
              </div>
              
              <div className="p-3 space-y-3 flex-1 overflow-y-auto max-h-[400px] custom-scrollbar">
                {daySchedules.map(schedule => (
                  <div 
                    key={schedule.id} 
                    className={cn(
                      "p-3 border rounded-xl shadow-sm hover:shadow-md transition-all group relative",
                      schedule.status === 'done' 
                        ? "bg-emerald-50 border-emerald-100" 
                        : "bg-white border-slate-100"
                    )}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Clock className={cn(
                          "w-3 h-3",
                          schedule.status === 'done' ? "text-emerald-500" : "text-indigo-500"
                        )} />
                        <span className={cn(
                          "text-xs font-bold",
                          schedule.status === 'done' ? "text-emerald-700" : "text-slate-600"
                        )}>{schedule.time}</span>
                      </div>
                      <button
                        onClick={() => handleToggleStatus(schedule)}
                        disabled={!canEdit}
                        className={cn(
                          "p-1 rounded-lg transition-all",
                          schedule.status === 'done' 
                            ? "text-emerald-600 bg-emerald-100" 
                            : "text-slate-300 hover:text-indigo-600 hover:bg-indigo-50"
                        )}
                        title={schedule.status === 'done' ? "Mark as Pending" : "Mark as Done"}
                      >
                        {schedule.status === 'done' ? <CheckCircle2 className="w-4 h-4" /> : <Circle className="w-4 h-4" />}
                      </button>
                    </div>
                    <div className="space-y-1.5 overflow-hidden">
                      <div className="flex items-start gap-2">
                        <User className="w-3 h-3 text-slate-400 mt-0.5 shrink-0" />
                        <div className="text-xs font-bold text-slate-900 leading-tight break-all min-w-0 flex-1">{schedule.patientName}</div>
                      </div>
                      <div className="flex items-start gap-2">
                        <Activity className="w-3 h-3 text-slate-400 mt-0.5 shrink-0" />
                        <div className="text-[10px] font-medium text-slate-500 leading-tight break-all min-w-0 flex-1">{schedule.operationType}</div>
                      </div>
                      <div className="flex items-start gap-2">
                        <UserCog className="w-3 h-3 text-slate-400 mt-0.5 shrink-0" />
                        <div className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider break-all min-w-0 flex-1">Dr. {schedule.doctor}</div>
                      </div>
                    </div>

                    {canEdit && (
                      <div className="mt-3 pt-2 border-t border-slate-50 flex justify-end">
                        <button
                          onClick={() => handleDeleteSchedule(schedule.id!)}
                          className="flex items-center gap-1 px-2 py-1 text-[10px] font-bold text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                        >
                          <Trash2 className="w-3 h-3" />
                          Delete
                        </button>
                      </div>
                    )}
                  </div>
                ))}
                {daySchedules.length === 0 && (
                  <div className="h-full flex flex-col items-center justify-center py-8 opacity-20">
                    <Calendar className="w-8 h-8 mb-2" />
                    <span className="text-[10px] font-bold uppercase tracking-widest">No Ops</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="glass-card w-full max-w-md rounded-3xl p-8 shadow-2xl animate-in fade-in zoom-in duration-200">
            <h3 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2">
              <Plus className="w-6 h-6 text-indigo-600" />
              Schedule Operation
            </h3>
            <form onSubmit={handleAddSchedule} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Patient Name</label>
                <input
                  type="text"
                  required
                  value={newSchedule.patientName}
                  onChange={e => setNewSchedule({ ...newSchedule, patientName: e.target.value })}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  placeholder="Full Name"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Date</label>
                  <select
                    value={newSchedule.date}
                    onChange={e => setNewSchedule({ ...newSchedule, date: e.target.value })}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  >
                    {days.map(day => (
                      <option key={day.toISOString()} value={format(day, 'yyyy-MM-dd')}>
                        {format(day, 'MMM d, yyyy')}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Time</label>
                  <input
                    type="time"
                    required
                    value={newSchedule.time}
                    onChange={e => setNewSchedule({ ...newSchedule, time: e.target.value })}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Type of Operation</label>
                <input
                  type="text"
                  required
                  value={newSchedule.operationType}
                  onChange={e => setNewSchedule({ ...newSchedule, operationType: e.target.value })}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  placeholder="e.g. Appendectomy"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Doctor</label>
                <input
                  type="text"
                  required
                  value={newSchedule.doctor}
                  onChange={e => setNewSchedule({ ...newSchedule, doctor: e.target.value })}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  placeholder="Dr. Name"
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 px-4 py-3 border border-slate-200 text-slate-600 rounded-xl font-bold hover:bg-slate-50 transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className={cn(
                    "flex-1 px-4 py-3 bg-indigo-600 text-white rounded-xl font-bold transition-all shadow-lg shadow-indigo-100",
                    isSubmitting ? "opacity-50 cursor-not-allowed" : "hover:bg-indigo-700"
                  )}
                >
                  {isSubmitting ? 'Saving...' : 'Save Schedule'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
