import React, { useMemo, useState } from 'react';
import { format, startOfMonth, addDays, getDaysInMonth, isSameDay, addMonths, subMonths } from 'date-fns';
import { Nurse, Schedule, ShiftType } from '../types';
import { SHIFTS } from '../constants';
import { cn } from '../lib/utils';
import { Download, Calendar as CalendarIcon, User as UserIcon, ChevronLeft, ChevronRight, RotateCcw, ArrowRightLeft } from 'lucide-react';
import * as XLSX from 'xlsx';

interface Props {
  nurses: Nurse[];
  schedules: Schedule[];
  isAdmin: boolean;
  onShiftChange?: (nurseId: string, date: string, shift: ShiftType) => void;
  currentMonth: Date;
  onMonthChange?: (date: Date) => void;
}

export default function ScheduleGrid({ nurses, schedules, isAdmin, onShiftChange, currentMonth, onMonthChange }: Props) {
  const days = useMemo(() => {
    const start = startOfMonth(currentMonth);
    const daysInMonth = getDaysInMonth(currentMonth);
    const result = [];
    
    for (let i = 0; i < daysInMonth; i++) {
      result.push(addDays(start, i));
    }
    return result;
  }, [currentMonth]);

  const getShift = (nurseId: string, date: Date) => {
    const dateStr = format(date, 'yyyy-MM-dd');
    return schedules.find(s => s.nurseId === nurseId && s.date === dateStr);
  };

  const handlePrevMonth = () => onMonthChange?.(subMonths(currentMonth, 1));
  const handleNextMonth = () => onMonthChange?.(addMonths(currentMonth, 1));
  const handleResetMonth = () => onMonthChange?.(new Date());

  const exportToExcel = () => {
    const data = nurses.map(nurse => {
      const row: any = { 'Nurse Name': nurse.name, 'Position': nurse.position };
      days.forEach(day => {
        const shift = getShift(nurse.id, day);
        row[format(day, 'MMM dd')] = shift ? shift.shift : 'RD';
      });
      return row;
    });

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Schedule');
    XLSX.writeFile(wb, `Nurse_Schedule_${format(currentMonth, 'MMM_yyyy')}.xlsx`);
  };

  return (
    <div className="glass-card rounded-2xl overflow-hidden">
      <div className="p-6 border-b border-white/10 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 bg-white/30">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 w-full lg:w-auto">
          <div>
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <CalendarIcon className="w-5 h-5 text-indigo-600" />
              {format(currentMonth, 'MMMM yyyy')}
            </h2>
            <p className="text-sm text-slate-500 mt-1 font-medium">Full Month Schedule</p>
          </div>
          
          <div className="flex items-center gap-1 bg-white/50 p-1 rounded-xl border border-white/20 shadow-sm">
            <button
              onClick={handlePrevMonth}
              className="p-2 hover:bg-white rounded-lg text-slate-600 transition-all active:scale-90"
              title="Previous Month"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={handleResetMonth}
              className="px-3 py-2 hover:bg-white rounded-lg text-slate-600 text-xs font-bold flex items-center gap-2 transition-all active:scale-95"
              title="Current Month"
            >
              <RotateCcw className="w-3 h-3" />
              Today
            </button>
            <button
              onClick={handleNextMonth}
              className="p-2 hover:bg-white rounded-lg text-slate-600 transition-all active:scale-90"
              title="Next Month"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        <button
          onClick={exportToExcel}
          className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-indigo-700 transition-all shadow-sm shadow-indigo-200 active:scale-95 w-full sm:w-auto justify-center"
        >
          <Download className="w-4 h-4" />
          Export Excel
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-white/40">
              <th className="sticky left-0 z-10 bg-white/80 backdrop-blur-md p-4 text-left text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-r border-white/20 min-w-[200px]">
                Employee Name
              </th>
              {days.map(day => (
                <th key={day.toISOString()} className="p-4 text-center text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-white/20 min-w-[80px]">
                  <div className="flex flex-col">
                    <span>{format(day, 'EEE')}</span>
                    <span className="text-slate-900 text-sm mt-0.5">{format(day, 'dd-MMM')}</span>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-white/10">
            {nurses.map(nurse => (
              <tr key={nurse.id} className="hover:bg-white/20 transition-colors group">
                <td className="sticky left-0 z-10 bg-white/60 backdrop-blur-md group-hover:bg-white/80 p-4 border-r border-white/20 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.05)]">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center font-bold text-xs">
                      {nurse.name.charAt(0)}
                    </div>
                    <div>
                      <div className="font-semibold text-slate-900 text-sm">{nurse.name}</div>
                      <div className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">{nurse.position}</div>
                    </div>
                  </div>
                </td>
                {days.map(day => {
                  const schedule = getShift(nurse.id, day);
                  const shiftConfig = SHIFTS.find(s => s.type === (schedule?.shift || 'RD'));
                  
                  return (
                    <td key={day.toISOString()} className="p-2 border-r border-white/10 last:border-r-0">
                      {isAdmin ? (
                        <select
                          value={schedule?.shift || 'RD'}
                          onChange={(e) => onShiftChange?.(nurse.id, format(day, 'yyyy-MM-dd'), e.target.value as ShiftType)}
                          className={cn(
                            "w-full p-2 rounded-lg text-[11px] font-bold border-2 transition-all cursor-pointer focus:ring-2 focus:ring-indigo-500 outline-none",
                            shiftConfig?.color,
                            shiftConfig?.textColor
                          )}
                        >
                          {SHIFTS.map(s => (
                            <option key={s.type} value={s.type}>{s.label}</option>
                          ))}
                        </select>
                      ) : (
                        <div className={cn(
                          "w-full p-2 rounded-lg text-[11px] font-bold border-2 text-center",
                          shiftConfig?.color,
                          shiftConfig?.textColor
                        )}>
                          {schedule?.shift || 'RD'}
                        </div>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <div className="p-4 bg-white/30 border-t border-white/10 flex flex-wrap gap-6 justify-center">
        {SHIFTS.map(s => (
          <div key={s.type} className="flex items-center gap-2">
            <div className={cn("w-4 h-4 rounded border", s.color)}></div>
            <span className="text-xs font-semibold text-slate-600">{s.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
