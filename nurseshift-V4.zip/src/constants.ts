import { ShiftType } from './types';

export const SHIFTS: { type: ShiftType; label: string; color: string; textColor: string }[] = [
  { 
    type: '6AM-6PM', 
    label: '6AM-6PM', 
    color: 'bg-amber-100 border-amber-200', 
    textColor: 'text-amber-800' 
  },
  { 
    type: '6PM-6AM', 
    label: '6PM-6AM', 
    color: 'bg-indigo-100 border-indigo-200', 
    textColor: 'text-indigo-800' 
  },
  { 
    type: '6AM-2PM', 
    label: '6AM-2PM', 
    color: 'bg-emerald-100 border-emerald-200', 
    textColor: 'text-emerald-800' 
  },
  { 
    type: '2PM-10PM', 
    label: '2PM-10PM', 
    color: 'bg-orange-100 border-orange-200', 
    textColor: 'text-orange-800' 
  },
  { 
    type: '10PM-6AM', 
    label: '10PM-6AM', 
    color: 'bg-[#efebe9] border-[#d7ccc8]', 
    textColor: 'text-[#5d4037]' 
  },
  { 
    type: '8AM-5PM', 
    label: '8AM-5PM', 
    color: 'bg-cyan-100 border-cyan-200', 
    textColor: 'text-cyan-800' 
  },
  { 
    type: 'RD', 
    label: 'RD', 
    color: 'bg-gray-100 border-gray-200', 
    textColor: 'text-gray-500' 
  },
  { 
    type: 'RRD', 
    label: 'RRD', 
    color: 'bg-red-100 border-red-200', 
    textColor: 'text-red-800' 
  },
];
