/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { doc, getDoc, onSnapshot } from 'firebase/firestore';
import { auth, db } from './firebase';
import { UserProfile, AppSettings } from './types';
import Login from './components/Login';
import AdminDashboard from './components/AdminDashboard';
import NurseView from './components/NurseView';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [settings, setSettings] = useState<AppSettings>({
    systemName: 'NurseShift Pro',
    backgroundUrl: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&q=80&w=2000',
    primaryColor: '#4f46e5',
    departments: ['Nursing', 'ER', 'ICU', 'Ward', 'OR']
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Listen for global settings
    const settingsUnsub = onSnapshot(doc(db, 'settings', 'global'), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data() as AppSettings;
        setSettings(prev => ({ ...prev, ...data }));
      }
    });

    let profileUnsub: (() => void) | null = null;

    const authUnsub = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
      
      // Clean up previous profile listener
      if (profileUnsub) {
        profileUnsub();
        profileUnsub = null;
      }

      if (firebaseUser) {
        // Set up real-time listener for the user's profile
        profileUnsub = onSnapshot(doc(db, 'users', firebaseUser.uid), (docSnap) => {
          if (docSnap.exists()) {
            setProfile(docSnap.data() as UserProfile);
          }
          setLoading(false);
        }, (err) => {
          console.error('Error listening to user profile:', err);
          setLoading(false);
        });
      } else {
        setProfile(null);
        setLoading(false);
      }
    });

    return () => {
      authUnsub();
      settingsUnsub();
      if (profileUnsub) profileUnsub();
    };
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin shadow-lg shadow-indigo-100"></div>
          <p className="text-slate-500 font-bold text-sm animate-pulse uppercase tracking-widest">Loading {settings.systemName}...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Dynamic Background */}
      <div 
        className="fixed inset-0 -z-10 bg-cover bg-center bg-no-repeat transition-all duration-1000"
        style={{ 
          backgroundImage: `linear-gradient(rgba(241, 245, 249, 0.7), rgba(241, 245, 249, 0.7)), url('${settings.backgroundUrl}')` 
        }}
      />
      
      {!user ? (
        <Login settings={settings} />
      ) : (profile?.role === 'admin' || profile?.role === 'head_nurse' || user.email === 'mct.lowelltorres@gmail.com') ? (
        <AdminDashboard settings={settings} userProfile={profile} />
      ) : (
        <NurseView settings={settings} userProfile={profile} />
      )}
    </>
  );
}
